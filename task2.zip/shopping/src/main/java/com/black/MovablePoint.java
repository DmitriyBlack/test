package com.black;


import javafx.util.Pair;

public class MovablePoint extends Point {
    private int xSpeed = 0;
    private int ySpeed = 0;

    // список констукторов обычно начинают с констурктора без параметров и потом постепенно более специфические
    public MovablePoint() {
    }

    public MovablePoint(int xSpeed, int ySpeed) {
        setXSpeed(xSpeed);
        setYSpeed(ySpeed);
    }

    public MovablePoint(int x, int y, int xSpeed, int ySpeed) {
        super(x,y);
        setXSpeed(xSpeed);
        setYSpeed(ySpeed);
    }

    // в случае переменной xSpeed нужно именовать методы так: getXSpeed, а не getXSpeed
    public int getXSpeed() {
        return xSpeed;
    }

    public void setXSpeed(int xSpeed) {
        this.xSpeed = xSpeed;
    }

    public int getYSpeed() {
        return ySpeed;
    }

    public void setYSpeed(int ySpeed) {
        this.ySpeed = ySpeed;
    }

    public Pair<Integer, Integer> getSpeed() {
        return new Pair<>(xSpeed, ySpeed);
    }

    public void setSpeed(int xSpeed, int ySpeed) {
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
    }

    public MovablePoint move() {
//        x += xSpeed;
//        y += ySpeed;
//        setXY(x, y);
        // т.к. переменные х и у мы сделали приватными, то теперь к ним нужно обращаться через геттеры и сеттеры
        setXY(getX() + getXSpeed(), getY() + getYSpeed());
        return this;
    }

    @Override
    public String toString() {
//        return "MovablePoint{" + "x=" + x
//                + ", y=" + y +
//                ", xSpeed=" + xSpeed +
//                ", ySpeed=" + ySpeed +
//                '}';
        // по условию нужно выводить другую строку. И нужно использовать toString() из Point
        return super.toString() + ", speed=(" + getXSpeed() + "," + getYSpeed() + ")";
    }
}
