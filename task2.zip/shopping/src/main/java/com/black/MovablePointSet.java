package com.black;

import java.util.ArrayList;

public class MovablePointSet {

//    final static int COORDINATES_MIN = 10;
//    final static int COORDINATES_MAX = 35;
//    final static int SPEED_MIN = 0;
//    final static int SPEED_MAX = 9;
//    final static int SPEED_MIN_DIAPASON = -3;
//    final static int SPEED_MAX_DIAPASON = 3;
//    final static int VALUE_OF_POINS = 5;
    // имена переменных лучше выбрать другие
    final static int COORDINATES_MIN = 10;
    final static int COORDINATES_MAX = 35;

    // лучше имя массива выбрать общее, не зависящее от типа переменной.
    // поля должны быть private
    private ArrayList<MovablePoint> points = new ArrayList<>();

    // по соглашению хорошим стилем программирования считается, когда в классе сначала должны идти статические поля
    // потом не статические поля
    // конструкторы начиная от более общих до более специфических
    // потом getters and setters и другие методы. быват что getters and setters ставят в самом конце, потому что они часто не несут особой логики.
    public MovablePointSet() {
    }

    public MovablePointSet(int numberOfPoints) {
        for (int i = 0; i < numberOfPoints; i++) {
            points.add(new MovablePoint(generateCoordinate(), generateCoordinate(), 0, 0));
        }
    }

    public boolean isValid(Point point) {
        // это сравнение корректно для сравнения целых значений..
        // в реальном проекте для сравнения вещественных чисел используется другой способ
        return COORDINATES_MIN <= point.getX() && point.getX() <= COORDINATES_MAX &&
               COORDINATES_MIN <= point.getY() && point.getY() <= COORDINATES_MAX;
    }

    public void addPoint(MovablePoint point) {
        if (isValid(point)) {
            points.add(point);
        } else {
            throw new IllegalArgumentException("Coordinates are out of allowed limits");
        }
    }

    public int generateCoordinate() {
        return MainApp.generate(COORDINATES_MIN, COORDINATES_MAX);
    }

    public void move(int xSpeed, int ySpeed) {
        for (MovablePoint p: points) {
            p.setSpeed(xSpeed, ySpeed);
            p.move();
            if (!isValid(p)) {
                throw new IllegalStateException("Point " + p + " is out of allowed range [" + COORDINATES_MIN + "," + COORDINATES_MAX + "]");
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        for (MovablePoint p: points) {
            s.append(p).append("\r\n");
        }
        return s.toString();
    }

    // эти два метода выглядят одинаково.. разница только в границах генерации координат..
    // поэтому можно вынести эту логику в отдельный метод
    // и сама логика генерации случайного числа немного неправильная
//    public int generateCoordinateRandomValue() {
//        return random.nextInt((COORDINATES_MAX - COORDINATES_MIN + 1) + COORDINATES_MIN);
//    }
//
//    public int generateSpeedRandomValue() {
//        return random.nextInt((SPEED_MAX - SPEED_MIN + 1) + SPEED_MIN);
//    }





    // вот этот метод должен быть сделан либо статическим, и возвращать при этом объект MovablePointSet
    // или как конструктор
//    public void createMovablePointSet(){
//        createMovablePointSet(2);
//    }


    // тут ты не использовал количество точек... всегда у тебя 2.
//    public void createMovablePointSet(int valueOfPoint) {
//        for (int i = 0; i < 2; i++) {
//            addPoint(new MovablePoint(generateCoordinateRandomValue(), generateCoordinateRandomValue(), 0, 0));
//
//        }
//    }

//    public void addPoint(MovablePoint point){
//        points.add(point);
//    }

//    public void makeRandomMove() {
//        int randomMove = random.nextInt((SPEED_MAX_DIAPASON - SPEED_MIN_DIAPASON + 1) + SPEED_MIN_DIAPASON);
//
//
//    }
//
//    public void printPointSet(){
//        for(MovablePoint point: points){
//            System.out.println(point.toString());
//        }
//        System.out.println();
//    }
}

