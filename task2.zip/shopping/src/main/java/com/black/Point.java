package com.black;

import javafx.util.Pair;

public class Point {

    private int x = 0;
    private int y = 0;
//    внутренние поля должны быть private
//    public long x;
//    public long y;

    // конструкторы должны быть public, только в случае если класс будет использоваться внутри пакета, констуркторы имеет
    // смысл делать package private
    public Point() {
    }

    public Point(int x, int y) {
        // в конструкторах можно использовать и сеттер методы, но я сталкивался, что зачастую их не спользуют...
        // это уже будет видно из стиля кода в проекте, что бы он был во всем проекте одинаковым.
        this.x = x;
        this.y = y;
    }

    // геттеры и сеттеры обычно группируют вместе по отношению к переменным.
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public Pair<Integer, Integer> getXY() {
//        Pair<long, long> point = new Pair<>(x, y);
//        return point;
        // удобнее возвращать значение сразу, не используя временную переменную
        return new Pair<>(x, y);
    }

    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
//        return "Point{" + this.getX() + "," + this.getY() + ")";
    // по условию нужно возвращать вот что
        return "(" + getX() + "," + getY() + ")";
    }
}
